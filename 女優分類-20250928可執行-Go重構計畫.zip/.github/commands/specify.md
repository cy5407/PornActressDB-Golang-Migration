---
description: Create or update the feature specification from a natural language feature description.
---

The user input to you can be provided directly by the agent or as a command argument - you **MUST** consider it before proceeding with the prompt (if not empty).

User input:

$ARGUMENTS

The text the user typed after `/specify` in the triggering message **is** the feature description. Assume you always have it available in this conversation even if `$ARGUMENTS` appears literally below. Do not ask the user to repeat it unless they provided an empty command.

Given that feature description, do this:

1. Run the script `.specify/scripts/powershell/create-new-feature.ps1 -Json "$ARGUMENTS"` from repo root and parse its JSON output for BRANCH_NAME and SPEC_FILE. All file paths must be absolute.
  **IMPORTANT** You must only ever run this script once. The JSON is provided in the terminal as output - always refer to it to get the actual content you're looking for.
2. Load `.specify/templates/spec-template.md` to understand required sections.
3. Write the specification to SPEC_FILE using the template structure, replacing placeholders with concrete details derived from the feature description (arguments) while preserving section order and headings.

4. **Specification Quality Validation**: After writing the initial spec, validate it against quality criteria:

   a. **Create Spec Quality Checklist**: Generate a checklist file at `FEATURE_DIR/checklists/requirements.md` using the checklist template structure with these validation items:
   
      ```markdown
      # Specification Quality Checklist: [FEATURE NAME]
      
      **Purpose**: Validate specification completeness and quality before proceeding to planning
      **Created**: [DATE]
      **Feature**: [Link to spec.md]
      
      ## Content Quality
      
      - [ ] CHK001 - No implementation details (languages, frameworks, APIs)
      - [ ] CHK002 - Focused on user value and business needs
      - [ ] CHK003 - Written for non-technical stakeholders
      - [ ] CHK004 - All mandatory sections completed
      
      ## Requirement Completeness
      
      - [ ] CHK005 - All functional requirements clearly stated
      - [ ] CHK006 - Non-functional requirements (performance, security, etc.) defined
      - [ ] CHK007 - Success criteria are measurable
      - [ ] CHK008 - Acceptance criteria are testable
      - [ ] CHK009 - Edge cases and error scenarios covered
      - [ ] CHK010 - Out-of-scope items explicitly excluded
      
      ## Clarity and Specificity
      
      - [ ] CHK011 - No vague adjectives ("fast", "scalable", "secure")
      - [ ] CHK012 - Concrete metrics and thresholds used
      - [ ] CHK013 - User roles and personas clearly defined
      - [ ] CHK014 - Workflows and interactions are explicit
      - [ ] CHK015 - Assumptions documented
      
      ## Consistency
      
      - [ ] CHK016 - Terminology used consistently throughout spec
      - [ ] CHK017 - Requirements don't conflict with each other
      - [ ] CHK018 - User stories align with functional requirements
      
      ## Traceability
      
      - [ ] CHK019 - Each user story links to requirements
      - [ ] CHK020 - Acceptance criteria map to requirements
      - [ ] CHK021 - Success metrics are measurable
      ```
   
   b. **Validate Checklist Items**: Automatically check the spec against each checklist item and mark passing items as `[x]` in the checklist file
   
   c. **Report Quality Issues**: If any checks fail, list them in the report with suggestions for improvement

5. Report completion with branch name, spec file path, checklist status, and readiness for the next phase.

Note: The script creates and checks out the new branch and initializes the spec file before writing.
