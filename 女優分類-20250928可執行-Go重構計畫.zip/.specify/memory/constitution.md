# 女優分類系統 - Go 重構 Constitution

## Core Principles

### 溝通規範
AI 助理回覆時一律使用繁體中文（台灣）； 程式碼註解使用繁體中文； 文件（README、註解、錯誤訊息）使用繁體中文； 變數名稱、函式名稱使用英文，但加上中文註解說明業務邏輯

### 漸進式重構策略
採用三階段漸進式重構，確保系統持續可用； 階段一優先重構後端核心邏輯（爬蟲、資料處理、並發控制）； 階段二建立 CLI 工具驗證核心功能； 階段三評估 GUI 方案（Fyne/Wails）或保留 Python GUI + Go REST API； 每階段完成後進行充分測試，確保功能正確性； 支援 Python 與 Go 版本並行運作，漸進式遷移使用者

### 程式碼品質
使用 Go 1.22+ （或最新穩定版）； 遵循 Go 官方編碼規範（Effective Go）； 遵循 Clean Code 原則：函式簡短、命名清楚、避免重複； 函式認知複雜度不超過 15 點（參考 SonarQube RSPEC-3776），使用 golangci-lint 的 gocognit 檢查； 使用 gofmt 和 golangci-lint 確保程式碼風格一致； 充分利用 Go 的並發特性（goroutines 和 channels），但需妥善管理並發數量

### 錯誤處理與日誌
所有錯誤都要明確處理，不使用 panic（除非真正無法恢復的錯誤）； 使用 error wrapping 保留完整錯誤鏈（fmt.Errorf("...: %w", err)）； 使用 zap 或 zerolog 結構化日誌，日誌訊息使用繁體中文； 詳細記錄每次爬蟲請求的日誌（成功/失敗/回應時間/編碼）； 網路請求失敗時自動重試最多 3 次，使用指數退避策略（exponential backoff with jitter）； 爬蟲錯誤分類記錄（網路錯誤、編碼錯誤、解析錯誤、逾時錯誤）

### 並發與效能
使用 goroutines 進行並發爬蟲，但必須限制並發數量（每個網域 3-5 個並發）； 使用 worker pool 模式管理 goroutine 生命週期，避免 goroutine 洩漏； 使用 context 管理逾時和取消操作（每個請求 30 秒逾時）； 使用 sync.WaitGroup 和 errgroup 協調併發任務； 使用 channel 在 goroutines 之間安全傳遞資料； 實作 graceful shutdown，確保程式終止時正確清理資源； 記憶體使用優化，避免一次性載入大量資料； 使用連線池（http.Client with Transport）複用連線

### 爬蟲最佳實踐
遵守網站 robots.txt 規範； 實作智慧頻率限制（rate limiting）：每個網域獨立限流設定； 使用 golang.org/x/time/rate 套件實作 token bucket 演算法； 支援 User-Agent 輪替，避免被封鎖； 實作智慧重試機制：區分暫時性錯誤（可重試）和永久性錯誤（不重試）； 支援 HTTP/2 和連線複用； 正確處理日文編碼（UTF-8, Shift-JIS, EUC-JP）：使用 golang.org/x/text/encoding 套件； 實作快取機制減少重複請求：使用記憶體快取或檔案快取； 記錄詳細的爬蟲統計資訊（成功率、回應時間、編碼分佈）

### 資料處理與儲存
使用 JSON 檔案作為資料庫，不依賴外部資料庫軟體； JSON 檔案結構設計：videos.json（影片資料）、actresses.json（女優資料）、studios.json（片商資料）、cache.json（爬蟲快取）； 每個 JSON 檔案獨立管理，支援並發讀取，寫入時需要檔案鎖定； 使用原子寫入（atomic write）模式：先寫入臨時檔案，再重新命名，避免資料損壞； 定期備份 JSON 檔案（保留最近 7 天）； 支援 JSON 檔案的匯入/匯出功能； 實作 JSON schema 驗證，確保資料完整性； 使用 encoding/json 的 stream decoder 處理大型 JSON 檔案； 敏感資料（如使用者偏好）可選擇性加密儲存

### 測試標準
使用 Go 標準測試框架（testing 套件）； 單元測試覆蓋率至少 70%； 關鍵爬蟲邏輯必須有表格驅動測試（table-driven tests）； 測試函式和測試案例描述使用繁體中文註解； 使用 testify/assert 簡化測試斷言； 網路請求使用 httptest 建立模擬伺服器； 並發程式碼使用 race detector 檢測競態條件（go test -race）； 整合測試使用真實網路請求（但加上快取避免過度請求）； CI/CD 管道中自動執行測試

### 專案結構
遵循標準 Go 專案布局； 清晰的模組化設計，高內聚低耦合； 使用 Go modules 管理相依套件； README.md 和文件使用繁體中文撰寫

標準目錄結構：
```
女優分類-go/
├── cmd/
│   ├── cli/                # CLI 工具
│   └── server/             # REST API 伺服器（可選）
├── internal/
│   ├── scraper/            # 爬蟲核心
│   │   ├── client/         # HTTP 客戶端
│   │   ├── parser/         # HTML 解析器
│   │   ├── ratelimit/      # 頻率限制器
│   │   └── sources/        # 各資料源實作（JAVDB、AV-WIKI）
│   ├── classifier/         # 分類邏輯
│   ├── database/           # JSON 資料庫管理
│   ├── models/             # 資料模型
│   └── config/             # 設定管理
├── pkg/                    # 可重用的公開套件
│   ├── encoding/           # 編碼檢測
│   └── retry/              # 重試機制
├── test/                   # 整合測試
├── data/                   # JSON 資料檔案
├── cache/                  # 快取檔案
├── docs/                   # 專案文件
├── scripts/                # 建構和部署腳本
├── go.mod
├── go.sum
├── Makefile
└── README.md
```

## GUI 開發標準

### GUI 技術選型評估

#### 選項一：Fyne (推薦給完全 Go 化專案)
- **優點**：純 Go 實作；跨平台；Material Design 風格；活躍社群；效能良好
- **缺點**：客製化彈性較低；複雜 UI 需較多程式碼
- **適用場景**：追求純 Go 技術棧，接受預設 UI 風格
- **相依套件**：`fyne.io/fyne/v2`
- **學習曲線**：中等

#### 選項二：Wails (推薦給需要現代化 UI)
- **優點**：使用 HTML/CSS/JavaScript 設計 UI；Go 處理後端邏輯；類似 Electron 但更輕量；支援 Vue/React/Svelte
- **缺點**：需要前端技術知識；打包體積較大
- **適用場景**：需要現代化複雜 UI，團隊有前端經驗
- **相依套件**：`github.com/wailsapp/wails/v2`
- **學習曲線**：需要前後端知識

#### 選項三：混合架構（推薦給漸進式遷移）
- **優點**：保留現有 Python tkinter GUI；Go 提供 REST API 後端；逐步遷移，風險最低
- **缺點**：需要維護兩種語言；部署較複雜
- **適用場景**：希望快速遷移核心邏輯，GUI 暫緩重構
- **實作方式**：Go 建立 HTTP 伺服器 + Python GUI 呼叫 API
- **學習曲線**：低（利用現有知識）

#### 選項四：Gio (適合追求極致效能)
- **優點**：純 Go；即時模式 GUI；最小記憶體佔用；極佳效能
- **缺點**：低階 API；開發複雜；社群較小；需要較多圖形知識
- **適用場景**：對效能有極致要求，願意投入學習成本
- **相依套件**：`gioui.org`
- **學習曲線**：高

### GUI 設計原則（適用所有選項）
使用者體驗優先：介面直觀、回應快速、錯誤提示清楚； 支援多語系（預設繁體中文）； 長時間操作（爬蟲）必須顯示進度條和可取消按鈕； 使用非阻塞 UI 模式：所有 I/O 操作在背景執行； 支援深色模式（可選）； 視窗大小和位置記憶功能； 鍵盤快捷鍵支援（Ctrl+Q 退出、Ctrl+S 儲存等）

### 階段三 GUI 實作建議
第一階段完成後評估技術選型； 建立 GUI 原型並請使用者測試； Fyne 實作範例：使用 container.Split、widget.List、binding 機制； Wails 實作範例：前端 Vue 3 + Go 後端，使用 wails binding； 混合架構範例：Go REST API（Gin framework）+ 現有 Python tkinter； 無論選擇何種方案，必須確保 GUI 不阻塞後端處理

## 開發流程與協作

Git 使用 GitHub Flow； 主分支（main）保持穩定且可部署； 功能開發使用 feature 分支，命名格式：`feature/功能簡述`； 重構使用 refactor 分支，命名格式：`refactor/模組名稱`； Commit 訊息使用繁體中文，格式為「類型: 簡短描述」（feat:、fix:、refactor:、docs:、test:）； 所有程式碼變更必須經過 code review； Review 重點包含：符合憲法原則、程式碼品質、測試覆蓋率、並發安全性、錯誤處理； 使用 GitHub Actions 或 GitLab CI 自動化測試和建構； 每個 PR 必須包含測試和文件更新

## 監控與可觀測性

記錄爬蟲請求統計（總請求數、成功率、平均回應時間、錯誤分佈）； 監控各資料源健康度（可用性、回應時間）； 記錄分類結果統計（影片數量、女優分佈、片商分佈）； 監控系統資源使用（CPU、記憶體、網路頻寬、磁碟空間）； 爬蟲錯誤立即記錄，連續失敗告警； JSON 資料檔案定期備份； 日誌檔案定期輪轉，保留至少 30 天； 提供 /health 端點檢查服務健康度（如使用 REST API 架構）； 提供 /metrics 端點匯出 Prometheus 格式監控指標（可選）

## 安全性

敏感設定（API 金鑰）使用環境變數或加密設定檔儲存； 所有外部通訊使用 HTTPS； 輸入驗證：檢查檔案路徑、影片編號格式，防止路徑穿越攻擊； 使用 CSRF token 保護 API 端點（如有 Web 介面）； 限制 API 請求頻率，防止濫用； 使用者偏好資料可選擇性加密儲存； 定期更新相依套件，修補安全漏洞（使用 `go list -u -m all` 檢查）； 不在日誌中記錄敏感資訊（密碼、API 金鑰）

## 相依套件管理

### 核心相依套件
- **HTTP 客戶端**：`net/http`（標準函式庫，優先使用）
- **HTML 解析**：`github.com/PuerkitoBio/goquery`（類似 BeautifulSoup）
- **編碼處理**：`golang.org/x/text/encoding`（處理日文編碼）
- **並發控制**：`golang.org/x/sync/errgroup`、`golang.org/x/time/rate`
- **日誌**：`go.uber.org/zap` 或 `github.com/rs/zerolog`
- **設定管理**：`github.com/spf13/viper`
- **CLI 工具**：`github.com/spf13/cobra` 或 `github.com/urfave/cli/v2`

### 測試相依套件
- **測試斷言**：`github.com/stretchr/testify`
- **HTTP 模擬**：`net/http/httptest`（標準函式庫）
- **Mock 產生器**：`github.com/golang/mock`（可選）

### GUI 相依套件（依選型而定）
- **Fyne**：`fyne.io/fyne/v2`
- **Wails**：`github.com/wailsapp/wails/v2`
- **Gio**：`gioui.org`
- **REST API**：`github.com/gin-gonic/gin`（混合架構）

### 相依套件原則
優先使用標準函式庫； 選擇維護活躍、社群支援良好的套件； 避免過度依賴，降低供應鏈風險； 定期檢查和更新相依套件； 使用 `go mod tidy` 清理未使用的相依套件

## 效能目標

爬蟲併發處理：同時處理至少 10 個網域的請求； 單一網域限流：每個網域每分鐘不超過 20 個請求； 快取命中率：至少 50%（重複請求使用快取）； 記憶體使用：常駐記憶體不超過 200MB； 啟動時間：CLI 工具啟動時間小於 1 秒； JSON 資料讀取：10000 筆影片資料讀取時間小於 500ms； 分類處理速度：每秒處理至少 50 個影片檔案； HTTP API 回應時間：P95 小於 200ms（如有 API）

## Governance

本憲法是專案開發的最高準則，所有開發活動必須遵循本文件規範； 如需修改本憲法，需經過專案團隊討論並達成共識； 所有 Pull Request 必須驗證是否符合憲法要求； 複雜決策（如技術選型、架構變更）必須有充分理由說明並記錄在 ADR（Architecture Decision Records）； 階段性重構完成時，需更新本憲法反映實際技術選型； 鼓勵實驗性改進，但必須在 feature 分支中進行，不影響主分支穩定性

## 附錄：重構檢查清單

### 階段一：後端核心邏輯
- [ ] 建立 Go 專案結構（cmd、internal、pkg）
- [ ] 實作 HTTP 客戶端和連線池
- [ ] 實作頻率限制器（每個網域獨立）
- [ ] 實作編碼自動檢測（日文編碼）
- [ ] 實作 HTML 解析器（goquery）
- [ ] 實作各資料源爬蟲（JAVDB、AV-WIKI、chiba-f）
- [ ] 實作快取機制（記憶體 + 檔案）
- [ ] 實作 JSON 資料庫（讀寫、原子操作、備份）
- [ ] 實作影片分類邏輯
- [ ] 實作錯誤處理和重試機制
- [ ] 單元測試覆蓋率 ≥ 70%
- [ ] 整合測試（真實網路請求）
- [ ] 效能測試（並發、記憶體）
- [ ] 文件撰寫（README、API 文件）

### 階段二：CLI 工具
- [ ] 使用 Cobra 建立 CLI 框架
- [ ] 實作搜尋命令（javdb search、avwiki search）
- [ ] 實作分類命令（classify）
- [ ] 實作統計命令（stats）
- [ ] 實作設定管理（config init、config set）
- [ ] 實作互動模式（互動式選擇）
- [ ] 實作進度顯示
- [ ] 實作日誌輸出控制（verbose、quiet）
- [ ] 建立 Makefile 簡化建構
- [ ] 跨平台建構測試（Windows、Linux、macOS）
- [ ] 效能基準測試（benchmark）

### 階段三：GUI 開發
- [ ] 完成 GUI 技術選型評估
- [ ] 建立 GUI 原型
- [ ] 實作主視窗和導航
- [ ] 實作搜尋介面
- [ ] 實作分類介面
- [ ] 實作設定介面
- [ ] 實作統計儀表板
- [ ] 實作進度顯示和取消功能
- [ ] 實作錯誤提示和通知
- [ ] 使用者測試和回饋收集
- [ ] 效能優化（UI 回應速度）
- [ ] 打包和安裝程式建立
- [ ] 使用者手冊撰寫

---

**Version**: 2.0.0  
**Ratified**: 2025-10-12  
**Last Amended**: 2025-10-12  
**Target Go Version**: 1.22+  
**Migration Strategy**: 漸進式三階段重構（Python → Go 核心 → CLI → GUI）